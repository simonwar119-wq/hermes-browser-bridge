// Hermes AI Assistant — Side Panel v3.0
// 核心功能：Claude AI 聊天、页面分析、流式输出、设置管理

// ============================================================
// 状态变量
// ============================================================

let apiKey = '';
let currentModel = 'deepseek-v4-flash';
let conversationHistory = []; // 对话历史（最多保留20条）
let pageTitle = '';
let pageUrl = '';
let pageContent = ''; // 当前页面文本内容
let isStreaming = false; // 是否正在流式输出

// ============================================================
// DOM 元素引用
// ============================================================

const chatArea = document.getElementById('chatArea');
const welcomeState = document.getElementById('welcomeState');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const charCount = document.getElementById('charCount');
const pageTitleEl = document.getElementById('pageTitle');
const pageUrlEl = document.getElementById('pageUrl');
const settingsBtn = document.getElementById('settingsBtn');
const closeSettingsBtn = document.getElementById('closeSettingsBtn');
const settingsOverlay = document.getElementById('settingsOverlay');
const apiKeyInput = document.getElementById('apiKeyInput');
const modelSelect = document.getElementById('modelSelect');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const clearBtn = document.getElementById('clearBtn');
const bridgeDot = document.getElementById('bridgeDot');
const bridgeStatusText = document.getElementById('bridgeStatusText');
const bridgeConnectBtn = document.getElementById('bridgeConnectBtn');
const bridgeDisconnectBtn = document.getElementById('bridgeDisconnectBtn');

// ============================================================
// 初始化
// ============================================================

async function init() {
  // 1. 从 storage 读取设置和历史
  const saved = await chrome.storage.local.get(['apiKey', 'model', 'conversationHistory']);
  apiKey = saved.apiKey || '';
  currentModel = saved.model || 'claude-haiku-4-5';
  conversationHistory = saved.conversationHistory || [];

  // 2. 同步设置面板 UI
  apiKeyInput.value = apiKey;
  modelSelect.value = currentModel;

  // 3. 更新页面上下文信息
  await updatePageContext();

  // 4. 渲染历史消息（最多显示最近20条）
  if (conversationHistory.length > 0) {
    welcomeState.style.display = 'none';
    const recent = conversationHistory.slice(-20);
    for (const msg of recent) {
      appendMessage(msg.role, msg.content, false);
    }
    scrollToBottom();
  }

  // 5. 检查 Bridge 状态
  checkBridgeStatus();

  // 6. 定期刷新页面上下文
  setInterval(updatePageContext, 8000);

  // 7. 监听来自 service worker 的消息
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'bridge_status') {
      updateBridgeUI(msg.connected);
    }
    // 处理右键菜单触发的快捷操作
    if (msg.type === 'quick_action') {
      handleQuickAction(msg.action);
    }
  });

  // 8. 如果没有 API Key，显示提示（允许用户先看到欢迎界面）
  if (!apiKey) {
    // 不强制打开设置，欢迎界面已包含引导
  }
}

// ============================================================
// 页面上下文
// ============================================================

async function updatePageContext() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;
    const tab = tabs[0];

    pageTitle = tab.title || '未知页面';
    pageUrl = tab.url || '';

    pageTitleEl.textContent = pageTitle;
    pageUrlEl.textContent = pageUrl.length > 60
      ? pageUrl.slice(0, 57) + '...'
      : pageUrl;

    // 异步获取页面内容（不阻塞 UI）
    fetchPageContent();
  } catch (e) {
    pageTitleEl.textContent = '无法获取页面信息';
  }
}

async function fetchPageContent() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'get_page_content' });
    pageContent = result?.text || '';
  } catch (e) {
    pageContent = '';
  }
}

// ============================================================
// 发送消息
// ============================================================

async function sendMessage(userInput) {
  const text = userInput.trim();
  if (!text || isStreaming) return;

  // 检查 API Key
  if (!apiKey) {
    showNoKeyNotice();
    return;
  }

  // 隐藏欢迎状态
  if (welcomeState.style.display !== 'none') {
    welcomeState.style.display = 'none';
  }

  // 添加用户消息到 UI
  appendMessage('user', text);

  // 添加到对话历史
  conversationHistory.push({ role: 'user', content: text });

  // 限制历史长度为20条
  if (conversationHistory.length > 20) {
    conversationHistory = conversationHistory.slice(-20);
  }

  // 清空输入框
  chatInput.value = '';
  chatInput.style.height = 'auto';
  charCount.textContent = '0';

  // 禁用输入
  setInputEnabled(false);

  // 显示打字动画
  const typingEl = showTypingIndicator();

  try {
    // 调用 Claude API（流式）
    const aiResponse = await callClaudeStream(conversationHistory, typingEl);

    // 添加 AI 回复到历史
    conversationHistory.push({ role: 'assistant', content: aiResponse });

    // 限制历史长度
    if (conversationHistory.length > 20) {
      conversationHistory = conversationHistory.slice(-20);
    }

    // 保存对话历史
    await chrome.storage.local.set({ conversationHistory });

  } catch (err) {
    // 移除打字动画
    typingEl.remove();
    // 显示错误消息
    appendMessage('error', `❌ 请求失败：${err.message}`);
  }

  // 恢复输入
  setInputEnabled(true);
  chatInput.focus();
}

// ============================================================
// Claude API 调用（流式 SSE）
// ============================================================

async function callClaudeStream(messages, typingEl) {
  // 构建 system prompt，包含页面上下文
  const contextParts = [`你是一个智能网页助手。`];
  if (pageTitle) contextParts.push(`当前页面标题：${pageTitle}`);
  if (pageUrl) contextParts.push(`当前页面 URL：${pageUrl}`);
  if (pageContent && pageContent.trim().length > 10) {
    contextParts.push(`\n页面内容摘要：\n${pageContent.slice(0, 3000)}`);
  }
  contextParts.push('\n请用中文回答，除非用户指定其他语言。保持回答清晰简洁。');

  const systemPrompt = contextParts.join('\n');

  // DeepSeek 使用 OpenAI 兼容格式，system 消息放在 messages 数组里
  const fullMessages = [
    { role: 'system', content: systemPrompt },
    ...messages,
  ];

  const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: currentModel,
      max_tokens: 2048,
      stream: true,
      messages: fullMessages,
    }),
  });

  if (!response.ok) {
    let errMsg = `HTTP ${response.status}`;
    try {
      const errData = await response.json();
      errMsg = errData?.error?.message || errMsg;
    } catch (e) {}

    if (response.status === 401) {
      errMsg = 'API Key 无效，请在设置中检查';
    } else if (response.status === 429) {
      errMsg = '请求过于频繁，请稍后再试';
    } else if (response.status === 500) {
      errMsg = '服务器错误，请稍后重试';
    }

    throw new Error(errMsg);
  }

  // 移除打字动画，创建 AI 消息气泡
  typingEl.remove();
  const { bubble, timeEl } = appendMessageEmpty('assistant');

  // 读取 SSE 流（DeepSeek 用 OpenAI 格式：choices[0].delta.content）
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let fullText = '';
  let buffer = '';

  isStreaming = true;

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const data = line.slice(6).trim();
        if (data === '[DONE]') continue;

        try {
          const parsed = JSON.parse(data);
          // OpenAI 兼容格式
          const delta = parsed.choices?.[0]?.delta?.content;
          if (delta) {
            fullText += delta;
            bubble.innerHTML = renderMarkdown(fullText);
            scrollToBottom();
          }
        } catch (e) {
          // 跳过解析失败的行
        }
      }
    }
  } finally {
    isStreaming = false;
  }

  timeEl.textContent = formatTime(new Date());

  return fullText;
}

// ============================================================
// Markdown 简单渲染（防 XSS）
// ============================================================

function renderMarkdown(text) {
  // 先转义 HTML 特殊字符（防 XSS）
  let html = escapeHtml(text);

  // 代码块（多行）```lang\ncode\n```
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    return `<pre><code>${code.trimEnd()}</code></pre>`;
  });

  // 行内代码 `code`
  html = html.replace(/`([^`\n]+)`/g, '<code>$1</code>');

  // 标题 ## / ###
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // 粗体 **text**
  html = html.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');

  // 斜体 *text*（单个星号，不影响列表）
  html = html.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');

  // 无序列表（- item 或 * item）
  html = html.replace(/^[-*] (.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>(\n)?)+/g, (match) => `<ul>${match}</ul>`);

  // 有序列表（1. item）
  html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');

  // 换行处理：两个换行 → 段落，单个换行 → <br>
  // 先处理段落（pre/ul/h 标签之间不加 p）
  const blocks = html.split(/\n\n+/);
  html = blocks.map(block => {
    const trimmed = block.trim();
    if (!trimmed) return '';
    // 已经是 HTML 块级元素
    if (/^<(pre|ul|ol|h[1-6]|li)/.test(trimmed)) return trimmed;
    // 普通段落：单换行转 <br>
    return `<p>${trimmed.replace(/\n/g, '<br>')}</p>`;
  }).join('');

  return html;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ============================================================
// 消息渲染
// ============================================================

function appendMessage(role, content, scrollTo = true) {
  if (welcomeState.style.display !== 'none') {
    welcomeState.style.display = 'none';
  }

  const msgEl = document.createElement('div');
  msgEl.className = `message ${role}`;

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';

  if (role === 'assistant') {
    bubble.innerHTML = renderMarkdown(content);
  } else if (role === 'error') {
    bubble.textContent = content;
  } else {
    // 用户消息：纯文本，换行转 <br>
    bubble.innerHTML = escapeHtml(content).replace(/\n/g, '<br>');
  }

  const timeEl = document.createElement('div');
  timeEl.className = 'message-time';
  timeEl.textContent = formatTime(new Date());

  msgEl.appendChild(bubble);
  msgEl.appendChild(timeEl);
  chatArea.appendChild(msgEl);

  if (scrollTo) scrollToBottom();
  return msgEl;
}

// 添加空的 AI 消息气泡（用于流式填充）
function appendMessageEmpty(role) {
  const msgEl = document.createElement('div');
  msgEl.className = `message ${role}`;

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  bubble.innerHTML = '';

  const timeEl = document.createElement('div');
  timeEl.className = 'message-time';

  msgEl.appendChild(bubble);
  msgEl.appendChild(timeEl);
  chatArea.appendChild(msgEl);
  scrollToBottom();

  return { msgEl, bubble, timeEl };
}

// 显示打字动画
function showTypingIndicator() {
  const msgEl = document.createElement('div');
  msgEl.className = 'message assistant';

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  bubble.innerHTML = `
    <div class="typing-indicator">
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    </div>
  `;

  msgEl.appendChild(bubble);
  chatArea.appendChild(msgEl);
  scrollToBottom();
  return msgEl;
}

function scrollToBottom() {
  chatArea.scrollTop = chatArea.scrollHeight;
}

function formatTime(date) {
  return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

// ============================================================
// 快捷操作
// ============================================================

const QUICK_ACTION_PROMPTS = {
  summarize: '请用中文总结这个页面的主要内容',
  keypoints: '提取这个页面的5个关键要点，用简洁的列表形式呈现',
  translate: '把这个页面的主要内容翻译成中文',
  analyze: '深入分析这个页面的内容，包括主要观点、数据和结论',
  explain: '用简单易懂的语言解释这个页面的核心概念',
};

function handleQuickAction(action) {
  const prompt = QUICK_ACTION_PROMPTS[action];
  if (!prompt) return;

  // 填入输入框并发送
  chatInput.value = prompt;
  charCount.textContent = prompt.length;
  sendMessage(prompt);
}

// 快捷按钮事件
document.querySelectorAll('.pill-btn[data-action]').forEach(btn => {
  btn.addEventListener('click', () => {
    const action = btn.dataset.action;
    handleQuickAction(action);
  });
});

// ============================================================
// 输入框事件
// ============================================================

// 自动扩展文本框高度（最多5行）
chatInput.addEventListener('input', () => {
  chatInput.style.height = 'auto';
  const maxHeight = parseInt(getComputedStyle(chatInput).lineHeight) * 5 + 16;
  chatInput.style.height = Math.min(chatInput.scrollHeight, maxHeight) + 'px';
  charCount.textContent = chatInput.value.length;
});

// Enter 发送，Shift+Enter 换行
chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage(chatInput.value);
  }
});

sendBtn.addEventListener('click', () => {
  sendMessage(chatInput.value);
});

function setInputEnabled(enabled) {
  chatInput.disabled = !enabled;
  sendBtn.disabled = !enabled;
}

// ============================================================
// API Key 未配置提示
// ============================================================

function showNoKeyNotice() {
  // 在聊天区显示提示，引导用户去设置
  if (welcomeState.style.display !== 'none') {
    welcomeState.style.display = 'none';
  }

  // 检查是否已有提示
  if (chatArea.querySelector('.no-key-notice')) return;

  const notice = document.createElement('div');
  notice.className = 'no-key-notice';
  notice.innerHTML = `
    <div class="notice-icon">🔑</div>
    <div class="notice-title">需要配置 API Key</div>
    <div class="notice-desc">请先在设置中配置 Claude API Key，才能开始聊天。</div>
    <button class="notice-settings-btn" id="noticGoSettingsBtn">前往设置</button>
  `;
  chatArea.appendChild(notice);

  document.getElementById('noticGoSettingsBtn').addEventListener('click', () => {
    openSettings();
  });

  scrollToBottom();
}

// ============================================================
// 清空对话
// ============================================================

clearBtn.addEventListener('click', async () => {
  if (!confirm('确定要清空所有对话记录吗？')) return;

  conversationHistory = [];
  await chrome.storage.local.set({ conversationHistory: [] });

  // 清空聊天区域
  chatArea.innerHTML = '';

  // 重新显示欢迎界面
  const welcome = document.createElement('div');
  welcome.className = 'welcome-state';
  welcome.id = 'welcomeState';
  welcome.innerHTML = `
    <div class="welcome-icon">🤖</div>
    <div class="welcome-title">你好，我是 Hermes AI</div>
    <div class="welcome-desc">我可以帮你分析当前页面内容，回答你的问题，或者总结页面要点。<br>点击上方快捷按钮开始，或直接输入问题。</div>
  `;
  chatArea.appendChild(welcome);
});

// ============================================================
// 设置面板
// ============================================================

function openSettings() {
  settingsOverlay.classList.add('open');
  // 刷新 Bridge 状态
  checkBridgeStatus();
}

function closeSettings() {
  settingsOverlay.classList.remove('open');
}

settingsBtn.addEventListener('click', openSettings);
closeSettingsBtn.addEventListener('click', closeSettings);

saveSettingsBtn.addEventListener('click', async () => {
  const newKey = apiKeyInput.value.trim();
  const newModel = modelSelect.value;

  apiKey = newKey;
  currentModel = newModel;

  await chrome.storage.local.set({ apiKey: newKey, model: newModel });

  // 显示保存成功反馈
  saveSettingsBtn.textContent = '✅ 已保存';
  setTimeout(() => {
    saveSettingsBtn.textContent = '保存设置';
  }, 1500);

  // 如果配置了 Key，关闭设置面板
  if (newKey) {
    setTimeout(closeSettings, 800);
  }
});

// ============================================================
// Bridge 状态
// ============================================================

async function checkBridgeStatus() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'check_bridge' });
    updateBridgeUI(result?.connected || false);
  } catch (e) {
    updateBridgeUI(false);
  }
}

function updateBridgeUI(connected) {
  bridgeDot.className = `status-dot ${connected ? 'connected' : 'disconnected'}`;
  bridgeStatusText.textContent = connected ? '已连接' : '未连接';
  bridgeConnectBtn.disabled = connected;
  bridgeDisconnectBtn.disabled = !connected;
}

bridgeConnectBtn.addEventListener('click', async () => {
  bridgeConnectBtn.disabled = true;
  bridgeConnectBtn.textContent = '连接中...';
  try {
    const result = await chrome.runtime.sendMessage({ type: 'bridge_connect' });
    updateBridgeUI(result?.connected || false);
  } catch (e) {
    updateBridgeUI(false);
  }
  bridgeConnectBtn.textContent = '连接';
});

bridgeDisconnectBtn.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'bridge_disconnect' });
  updateBridgeUI(false);
});

// ============================================================
// 启动
// ============================================================

init();
