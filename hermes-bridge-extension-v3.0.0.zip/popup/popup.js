// Hermes Browser Bridge — Popup UI v2.0
// 双模式：AI Mode（默认，使用 Chrome 内置 AI）+ Bridge Mode（可选，连接 Hermes Agent）

// ============================================================
// DOM 引用
// ============================================================

// Mode tabs
const TAB_AI = document.getElementById('tabAI');
const TAB_BRIDGE = document.getElementById('tabBridge');
const PANEL_AI = document.getElementById('panelAI');
const PANEL_BRIDGE = document.getElementById('panelBridge');

// AI panel
const AI_DOT = document.getElementById('aiDot');
const AI_STATUS = document.getElementById('aiStatusText');
const TAB_DETAIL = document.getElementById('tabDetail');
const BTN_SUMMARIZE = document.getElementById('btnSummarize');
const BTN_ANALYZE = document.getElementById('btnAnalyze');

// Bridge panel
const BRIDGE_DOT = document.getElementById('bridgeStatusDot');
const BRIDGE_STATUS = document.getElementById('bridgeStatusText');
const CONNECT_BTN = document.getElementById('connectBtn');
const DISCONNECT_BTN = document.getElementById('disconnectBtn');
const HOST_INPUT = document.getElementById('bridgeHost');
const PORT_INPUT = document.getElementById('bridgePort');
const LOG = document.getElementById('log');

// ============================================================
// 状态
// ============================================================

let currentMode = 'ai'; // 'ai' | 'bridge'
let aiReady = false;
let bridgeConnected = false;

// ============================================================
// 初始化
// ============================================================

async function init() {
  // 加载保存的 Bridge 配置
  const saved = await chrome.storage.local.get(['bridgeHost', 'bridgePort']);
  if (saved.bridgePort) PORT_INPUT.value = saved.bridgePort;
  if (saved.bridgeHost) HOST_INPUT.value = saved.bridgeHost;

  // 更新标签页信息
  updateTabInfo();

  // 检查 AI 可用性
  checkAI();

  // 检查 Bridge 状态
  checkBridge();

  // 监听来自 service worker 的消息
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'bridge_status') {
      updateBridgeUI(msg.connected);
    }
  });
}

// ============================================================
// 标签页信息
// ============================================================

async function updateTabInfo() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length > 0) {
      const tab = tabs[0];
      const title = (tab.title || 'Untitled').slice(0, 40);
      const url = (tab.url || '').slice(0, 50);
      TAB_DETAIL.textContent = `📄 ${title}\n${url}`;
    } else {
      TAB_DETAIL.textContent = '❌ No active tab';
    }
  } catch (e) {
    TAB_DETAIL.textContent = '⚠️ Cannot get tab info';
  }
}

// ============================================================
// AI 模式
// ============================================================

async function checkAI() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'check_ai' });

    if (result?.available) {
      const state = result.state;
      if (state === 'readily') {
        AI_DOT.className = 'dot ready';
        AI_STATUS.textContent = '✅ AI ready — on-device Gemini Nano';
        aiReady = true;
      } else if (state === 'after-download') {
        AI_DOT.className = 'dot pending';
        AI_STATUS.textContent = '⏳ AI model needs download (click to trigger)';
        aiReady = true; // 仍可点击，会触发下载
      }
    } else {
      AI_DOT.className = 'dot unavailable';
      AI_STATUS.textContent = '❌ Built-in AI not available';
      aiReady = false;
    }
  } catch (err) {
    AI_DOT.className = 'dot unavailable';
    AI_STATUS.textContent = '❌ AI check failed';
    aiReady = false;
  }
}

// ============================================================
// Bridge 模式
// ============================================================

async function checkBridge() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'check_bridge' });
    updateBridgeUI(result?.connected || false);
  } catch (e) {
    updateBridgeUI(false);
  }
}

function updateBridgeUI(connected) {
  bridgeConnected = connected;
  BRIDGE_DOT.style.background = connected ? '#22c55e' : '#ef4444';
  BRIDGE_STATUS.textContent = connected ? 'Connected' : 'Disconnected';
  CONNECT_BTN.disabled = connected;
  DISCONNECT_BTN.disabled = !connected;
}

// ============================================================
// 模式切换
// ============================================================

function switchMode(mode) {
  currentMode = mode;
  TAB_AI.classList.toggle('active', mode === 'ai');
  TAB_BRIDGE.classList.toggle('active', mode === 'bridge');
  PANEL_AI.classList.toggle('active', mode === 'ai');
  PANEL_BRIDGE.classList.toggle('active', mode === 'bridge');
}

TAB_AI.addEventListener('click', () => switchMode('ai'));
TAB_BRIDGE.addEventListener('click', () => switchMode('bridge'));

// ============================================================
// AI 操作（总结 / 分析）
// ============================================================

async function triggerAIAction(mode) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs.length === 0) {
    addLog('❌ No active tab');
    return;
  }

  const tab = tabs[0];
  const actionType = mode === 'summarize' ? 'ai_summarize' : 'ai_analyze';

  try {
    const result = await chrome.runtime.sendMessage({ type: actionType, tabId: tab.id });

    if (result?.error) {
      addLog(`❌ ${result.error}`);
      return;
    }

    addLog(mode === 'summarize' ? '📝 Summarizing...' : '🔬 Analyzing...');
    window.close(); // 弹出结果标签页后关闭 popup
  } catch (err) {
    addLog(`❌ Error: ${err.message}`);
  }
}

BTN_SUMMARIZE.addEventListener('click', () => triggerAIAction('summarize'));
BTN_ANALYZE.addEventListener('click', () => triggerAIAction('analyze'));

// ============================================================
// Bridge 连接控制
// ============================================================

CONNECT_BTN.addEventListener('click', async () => {
  // 保存配置
  await chrome.storage.local.set({
    bridgeHost: HOST_INPUT.value,
    bridgePort: PORT_INPUT.value,
  });

  chrome.runtime.sendMessage({ type: 'bridge_connect' }, (result) => {
    if (result?.connected) {
      addLog('✅ Connected to bridge server');
      updateBridgeUI(true);
    } else {
      addLog('❌ Connection failed — server not running?');
    }
  });
});

DISCONNECT_BTN.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'bridge_disconnect' }, () => {
    addLog('🔌 Disconnected');
    updateBridgeUI(false);
  });
});

// ============================================================
// 辅助
// ============================================================

function addLog(msg) {
  const time = new Date().toLocaleTimeString();
  LOG.textContent = `[${time}] ${msg}`;
}

// ============================================================
// 定期刷新
// ============================================================

setInterval(updateTabInfo, 5000);

// ============================================================
// 启动
// ============================================================

init();
