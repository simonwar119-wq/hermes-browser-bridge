// Hermes Browser Bridge — Service Worker v2.0
// 双模式：Standalone AI（默认，使用 Chrome 内置 Gemini Nano）+ Bridge（可选，连接 Hermes Agent）
//
// 模式 1 — AI Mode: 总结/分析通过 Chrome 内置 AI 完成，无需任何外部连接
// 模式 2 — Bridge Mode: 保留 WebSocket 连接 Hermes Agent，实现完整浏览器控制

// ============================================================
// 配置
// ============================================================

const CONFIG = {
  // Bridge 连接
  bridgeHost: '127.0.0.1',
  bridgePort: 8643,
  reconnectBaseDelay: 1000,
  reconnectMaxDelay: 30000,
  keepAliveInterval: 20, // seconds

  // AI
  aiSystemPrompt: 'You are a helpful AI assistant that summarizes and analyzes web page content. Be clear, concise, and accurate.',
  aiTemperature: 0.4,
  aiTopK: 3,
};

// ============================================================
// 状态
// ============================================================

let ws = null;
let connected = false;
let reconnectAttempts = 0;
let reconnectTimer = null;

// ============================================================
// AI API 管理
// ============================================================

// 查找可用的 Chrome AI API（兼容不同 Chrome 版本）
async function findAIAPI() {
  const candidates = [
    () => chrome.ai?.languageModel,
    () => chrome.aiOriginTrial?.languageModel,
    () => self.ai?.languageModel,
    () => window.ai?.languageModel,
  ];
  for (const getter of candidates) {
    try {
      const api = getter();
      if (api) return api;
    } catch (e) { /* try next */ }
  }
  return null;
}

// 检查 AI 可用性
async function checkAIAvailability() {
  try {
    const api = await findAIAPI();
    if (!api) return { available: false, reason: 'not-supported' };

    const caps = await api.capabilities();
    return {
      available: caps.available !== 'no',
      state: caps.available, // 'readily' | 'after-download' | 'no'
    };
  } catch (err) {
    return { available: false, reason: err.message };
  }
}

// 获取页面文本（供 AI 处理）
async function getPageText(tabId) {
  try {
    const result = await chrome.tabs.sendMessage(tabId, {
      type: 'read',
      selector: null,
    });
    return result.text || '';
  } catch (err) {
    // 内容脚本未就绪，尝试注入后重试
    try {
      await chrome.tabs.reload(tabId);
      await new Promise(r => setTimeout(r, 1500));
      const result = await chrome.tabs.sendMessage(tabId, {
        type: 'read',
        selector: null,
      });
      return result.text || '';
    } catch (e2) {
      throw new Error('Cannot read page content: ' + (err.message || 'content script not ready'));
    }
  }
}

// 执行 AI 处理：创建任务 + 打开结果页
async function runAITask(mode, tabId) {
  // 获取页面信息
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) throw new Error('Tab not found');

  // 获取页面内容
  const text = await getPageText(tabId);
  if (!text || text.trim().length < 10) {
    throw new Error('Page has no readable content');
  }

  // 生成任务 ID
  const taskId = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  // 保存任务数据到 storage（AI 结果页读取）
  await chrome.storage.local.set({
    [`ai_task_${taskId}`]: {
      type: mode,
      text: text.slice(0, 30000), // 限制长度
      url: tab.url,
      title: tab.title,
      timestamp: Date.now(),
    },
  });

  // 打开结果页（在新标签页中）
  await chrome.tabs.create({
    url: chrome.runtime.getURL(`ai/results.html?mode=${mode}&taskId=${taskId}`),
    active: true,
  });

  return { success: true, taskId };
}

// ============================================================
// WebSocket Bridge 管理（仅高级用户使用）
// ============================================================

async function getBridgeUrl() {
  const { bridgeHost } = await chrome.storage.local.get(['bridgeHost']);
  return `ws://${bridgeHost || CONFIG.bridgeHost}:${CONFIG.bridgePort}/extension`;
}

async function bridgeConnect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }

  const url = await getBridgeUrl();

  ws = new WebSocket(url);

  ws.onopen = () => {
    console.log('[Hermes Bridge] ✅ Bridge connected');
    connected = true;
    reconnectAttempts = 0;
    notifyPopup({ type: 'connection_status', connected: true });
    notifyPopup({ type: 'bridge_status', connected: true });
  };

  ws.onmessage = async (event) => {
    try {
      const message = JSON.parse(event.data);
      await handleBridgeMessage(message);
    } catch (err) {
      console.warn('[Hermes Bridge] Invalid message:', err);
    }
  };

  ws.onclose = () => {
    console.log('[Hermes Bridge] ❌ Bridge disconnected');
    connected = false;
    ws = null;
    notifyPopup({ type: 'connection_status', connected: false });
    notifyPopup({ type: 'bridge_status', connected: false });
    scheduleReconnect();
  };

  ws.onerror = () => {
    // onclose fires after error
  };
}

function bridgeDisconnect() {
  if (ws) {
    ws.close();
    ws = null;
  }
  connected = false;
  reconnectAttempts = 0;
  clearTimeout(reconnectTimer);
  notifyPopup({ type: 'connection_status', connected: false });
  notifyPopup({ type: 'bridge_status', connected: false });
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  const delay = Math.min(
    CONFIG.reconnectBaseDelay * Math.pow(2, reconnectAttempts),
    CONFIG.reconnectMaxDelay
  );
  reconnectAttempts++;
  reconnectTimer = setTimeout(() => { bridgeConnect(); }, delay);
}

// ============================================================
// Bridge 消息处理（来自 Hermes Agent 的浏览器命令）
// ============================================================

async function handleBridgeMessage(message) {
  const { type, action, params, request_id } = message;

  if (type === 'pong') return;
  if (type === 'ping') {
    sendToBridge({ type: 'pong' });
    return;
  }

  if (type === 'browser_action' || action) {
    const rid = request_id || generateId();
    try {
      const result = await executeBrowserAction(action || type, params || {});
      notifyPopup({ type: 'action_completed', action: action || type, status: 'ok', timestamp: Date.now() });
      sendToBridge({
        type: 'browser_action_response',
        request_id: rid,
        status: 'ok',
        data: result,
      });
    } catch (err) {
      sendToBridge({
        type: 'browser_action_response',
        request_id: rid,
        status: 'error',
        error: err.message || String(err),
      });
    }
    return;
  }

  console.warn('[Hermes Bridge] Unknown message type:', type);
}

function sendToBridge(data) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

// ============================================================
// 浏览器操作（供 Hermes Agent 使用）
// ============================================================

async function executeBrowserAction(action, params) {
  switch (action) {
    case 'navigate': return await actionNavigate(params);
    case 'read': return await actionRead(params);
    case 'click': return await actionClick(params);
    case 'fill': return await actionFill(params);
    case 'screenshot': return await actionScreenshot(params);
    case 'extract': return await actionExtract(params);
    case 'scroll': return await actionScroll(params);
    case 'get_tabs': return await actionGetTabs();
    case 'activate_tab': return await actionActivateTab(params);
    case 'wait': return await actionWait(params);
    case 'get_active_tab': return await getActiveTab();
    case 'inject': return await actionInject(params);
    case 'reload_and_inject': return await actionReloadAndInject(params);
    default: throw new Error(`Unknown action: ${action}`);
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs.length > 0 ? tabs[0] : null;
}

async function ensureActiveTab() {
  const tab = await getActiveTab();
  if (!tab) throw new Error('No active tab found');
  return tab;
}

async function actionNavigate(params) {
  const url = params.url;
  if (!url) throw new Error('URL required');
  let tab = await getActiveTab();
  if (!tab) {
    tab = await chrome.tabs.create({ url });
  } else {
    await chrome.tabs.update(tab.id, { url, active: true });
  }
  await waitForTabLoad(tab.id);
  const updated = await chrome.tabs.get(tab.id);
  return { url: updated.url, title: updated.title, status: updated.status };
}

async function actionRead(params) {
  const tab = await ensureActiveTab();
  const result = await chrome.tabs.sendMessage(tab.id, { type: 'read', selector: params.selector || null });
  return result;
}

async function actionClick(params) {
  const tab = await ensureActiveTab();
  if (!params.selector) throw new Error('Selector required');
  return await chrome.tabs.sendMessage(tab.id, { type: 'click', selector: params.selector });
}

async function actionFill(params) {
  const tab = await ensureActiveTab();
  if (!params.selector) throw new Error('Selector required');
  return await chrome.tabs.sendMessage(tab.id, { type: 'fill', selector: params.selector, value: params.value || '', humanLike: params.humanLike !== false });
}

async function actionScreenshot(params) {
  const format = params.format || 'png';
  const dataUrl = await chrome.tabs.captureVisibleTab(null, { format });
  return { image: dataUrl, format };
}

async function actionExtract(params) {
  const tab = await ensureActiveTab();
  return await chrome.tabs.sendMessage(tab.id, { type: 'extract', selectors: params.selectors || {} });
}

async function actionScroll(params) {
  const tab = await ensureActiveTab();
  return await chrome.tabs.sendMessage(tab.id, { type: 'scroll', direction: params.direction || 'down', amount: params.amount || null });
}

async function actionGetTabs() {
  const tabs = await chrome.tabs.query({});
  return { tabs: tabs.map(t => ({ id: t.id, title: t.title, url: t.url, active: t.active })) };
}

async function actionActivateTab(params) {
  await chrome.tabs.update(params.tabId, { active: true });
  await waitForTabLoad(params.tabId);
  const tab = await chrome.tabs.get(params.tabId);
  return { id: tab.id, url: tab.url, title: tab.title };
}

async function actionWait(params) {
  const ms = params.ms || 1000;
  await new Promise(r => setTimeout(r, ms));
  return { waited: ms };
}

async function actionInject(params) {
  const tab = await ensureActiveTab();
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'ping' });
    return { injected: true, tabId: tab.id };
  } catch (err) {
    return { injected: false, reason: 'content script not responding' };
  }
}

async function actionReloadAndInject(params) {
  const tab = await ensureActiveTab();
  await chrome.tabs.reload(tab.id);
  await waitForTabLoad(tab.id);
  return { reloaded: true, tabId: tab.id };
}

function waitForTabLoad(tabId, timeout = 15000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve({ timeout: true });
    }, timeout);
    const listener = (id, changeInfo) => {
      if (id === tabId && changeInfo.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve({ loaded: true }), 500);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// ============================================================
// 上下文菜单（独立 AI 模式也可用）
// ============================================================

function ensureContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'hermes-summarize',
      title: '📝 让 Hermes AI 总结本页',
      contexts: ['page'],
    });
    chrome.contextMenus.create({
      id: 'hermes-analyze',
      title: '🔬 让 Hermes AI 分析本页',
      contexts: ['page'],
    });
    chrome.contextMenus.create({
      id: 'hermes-separator',
      title: '— 需 Bridge 连接 —',
      contexts: ['page'],
    });
    chrome.contextMenus.create({
      id: 'hermes-send-page',
      title: '发送给 Hermes Agent',
      contexts: ['page'],
    });
    chrome.contextMenus.create({
      id: 'hermes-send-selection',
      title: '处理选中文字',
      contexts: ['selection'],
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const pageInfo = {
    url: tab?.url || info.pageUrl,
    title: tab?.title || '',
    selectionText: info.selectionText || null,
    timestamp: Date.now(),
  };

  // AI 功能 — 无需任何连接
  if (info.menuItemId === 'hermes-summarize') {
    try {
      await runAITask('summarize', tab.id);
    } catch (err) {
      notifyPopup({ type: 'context_menu_result', success: false, error: err.message });
    }
    return;
  }

  if (info.menuItemId === 'hermes-analyze') {
    try {
      await runAITask('analyze', tab.id);
    } catch (err) {
      notifyPopup({ type: 'context_menu_result', success: false, error: err.message });
    }
    return;
  }

  // Bridge 功能 — 需要连接
  if (!connected) {
    notifyPopup({ type: 'context_menu_result', success: false, error: '未连接到 Bridge Server' });
    return;
  }

  let action = 'ask';
  if (info.menuItemId === 'hermes-send-page') action = 'analyze_page';
  else if (info.menuItemId === 'hermes-send-selection') action = 'process_selection';

  sendToBridge({
    type: 'context_menu_action',
    request_id: generateId(),
    data: { ...pageInfo, action },
  });

  notifyPopup({
    type: 'context_menu_result',
    success: true,
    action,
    message: `已发送给 Hermes: ${action === 'analyze_page' ? '分析页面' : '处理选中文字'}`,
  });
});

// ============================================================
// Service Worker 保活
// ============================================================

function ensureKeepAlive() {
  chrome.alarms.create('hermes-bridge-keepalive', { periodInMinutes: CONFIG.keepAliveInterval / 60 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'hermes-bridge-keepalive') {
    // 不再自动连接 Bridge — 由用户手动触发
    // 仅在已经连接但断开时尝试重连
  }
});

// ============================================================
// 消息路由（接收 Popup / Side Panel 请求）
// ============================================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 异步处理并保持通道开放
  (async () => {
    try {
      const result = await handleMessage(message, sender);
      sendResponse(result || {});
    } catch (err) {
      sendResponse({ error: err.message });
    }
  })();
  return true; // 保持 sendResponse 可用
});

async function handleMessage(message, sender) {
  switch (message.type) {

    // === AI 功能 ===
    case 'ai_summarize':
    case 'ai_analyze': {
      const mode = message.type === 'ai_summarize' ? 'summarize' : 'analyze';
      const tabId = message.tabId || sender.tab?.id;
      if (!tabId) throw new Error('No tab ID');

      return await runAITask(mode, tabId);
    }

    case 'check_ai': {
      return await checkAIAvailability();
    }

    case 'check_bridge': {
      return { connected };
    }

    // === Bridge 连接管理 ===
    case 'bridge_connect': {
      await bridgeConnect();
      // 等一会儿看是否连上
      await new Promise(r => setTimeout(r, 1500));
      return { connected };
    }

    case 'bridge_disconnect': {
      bridgeDisconnect();
      return { connected: false };
    }

    case 'get_connection_status': {
      return { connected };
    }

    default:
      return { error: `Unknown message type: ${message.type}` };
  }
}

// ============================================================
// 通知 Popup
// ============================================================

function notifyPopup(data) {
  try {
    chrome.runtime.sendMessage(data).catch(() => {});
  } catch (e) {
    // popup 未打开时忽略
  }
}

// ============================================================
// 初始化
// ============================================================

ensureKeepAlive();
ensureContextMenus();
console.log('[Hermes Bridge] v2.0 loaded — AI mode ready');
