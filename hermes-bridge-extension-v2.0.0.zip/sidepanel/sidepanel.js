// Hermes Browser Bridge — Side Panel v2.0

// Mode tabs
const SIDE_TAB_AI = document.getElementById('sideTabAI');
const SIDE_TAB_BRIDGE = document.getElementById('sideTabBridge');
const SIDE_PANEL_AI = document.getElementById('sidePanelAI');
const SIDE_PANEL_BRIDGE = document.getElementById('sidePanelBridge');

// AI
const SIDE_AI_DOT = document.getElementById('sideAiDot');
const SIDE_AI_STATUS = document.getElementById('sideAiStatus');
const SIDE_TAB_TITLE = document.getElementById('sideTabTitle');
const SIDE_TAB_URL = document.getElementById('sideTabUrl');
const SIDE_BTN_SUMMARIZE = document.getElementById('sideBtnSummarize');
const SIDE_BTN_ANALYZE = document.getElementById('sideBtnAnalyze');
const SIDE_LOG = document.getElementById('sideActionLog');

// Bridge
const SIDE_BRIDGE_DOT = document.getElementById('sideBridgeDot');
const SIDE_BRIDGE_STATUS = document.getElementById('sideBridgeStatus');
const SIDE_BTN_CONNECT = document.getElementById('sideBtnConnect');
const SIDE_BTN_DISCONNECT = document.getElementById('sideBtnDisconnect');
const SIDE_HOST = document.getElementById('sideBridgeHost');
const SIDE_PORT = document.getElementById('sideBridgePort');

// ============================================================
// 初始化
// ============================================================

async function init() {
  // 加载 Bridge 配置
  const saved = await chrome.storage.local.get(['bridgeHost', 'bridgePort']);
  if (saved.bridgePort) SIDE_PORT.value = saved.bridgePort;
  if (saved.bridgeHost) SIDE_HOST.value = saved.bridgeHost;

  updateTabInfo();
  checkAI();
  checkBridge();

  // 定期刷新
  setInterval(updateTabInfo, 5000);

  // 监听消息
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'bridge_status') {
      updateBridgeUI(msg.connected);
    }
  });
}

// ============================================================
// 标签页信息
// ============================================================

async function updateTabInfo() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length > 0) {
      const tab = tabs[0];
      SIDE_TAB_TITLE.textContent = tab.title || 'Untitled';
      SIDE_TAB_URL.textContent = tab.url || '';
    }
  } catch (e) {
    // ignore
  }
}

// ============================================================
// AI
// ============================================================

async function checkAI() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'check_ai' });
    if (result?.available) {
      SIDE_AI_DOT.className = 'dot ' + (result.state === 'readily' ? 'ready' : 'pending');
      SIDE_AI_STATUS.textContent = result.state === 'readily'
        ? '✅ AI ready'
        : '⏳ AI will download on first use';
    } else {
      SIDE_AI_DOT.className = 'dot unavailable';
      SIDE_AI_STATUS.textContent = '❌ AI not available';
    }
  } catch (e) {
    SIDE_AI_DOT.className = 'dot unavailable';
    SIDE_AI_STATUS.textContent = '❌ Error checking AI';
  }
}

// ============================================================
// Bridge
// ============================================================

async function checkBridge() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'check_bridge' });
    updateBridgeUI(result?.connected || false);
  } catch (e) {
    updateBridgeUI(false);
  }
}

function updateBridgeUI(connected) {
  SIDE_BRIDGE_DOT.style.background = connected ? '#22c55e' : '#ef4444';
  SIDE_BRIDGE_STATUS.textContent = connected ? 'Connected' : 'Disconnected';
  SIDE_BTN_CONNECT.disabled = connected;
  SIDE_BTN_DISCONNECT.disabled = !connected;
}

// ============================================================
// 模式切换
// ============================================================

function switchMode(mode) {
  SIDE_TAB_AI.classList.toggle('active', mode === 'ai');
  SIDE_TAB_BRIDGE.classList.toggle('active', mode === 'bridge');
  SIDE_PANEL_AI.classList.toggle('active', mode === 'ai');
  SIDE_PANEL_BRIDGE.classList.toggle('active', mode === 'bridge');
}

SIDE_TAB_AI.addEventListener('click', () => switchMode('ai'));
SIDE_TAB_BRIDGE.addEventListener('click', () => switchMode('bridge'));

// ============================================================
// AI 操作
// ============================================================

async function triggerAIAction(mode) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs.length === 0) {
    addLogItem('error', 'No active tab');
    return;
  }

  const tab = tabs[0];
  const actionType = mode === 'summarize' ? 'ai_summarize' : 'ai_analyze';

  try {
    const result = await chrome.runtime.sendMessage({ type: actionType, tabId: tab.id });
    if (result?.error) {
      addLogItem('error', `Error: ${result.error}`);
    } else {
      addLogItem(mode, `${mode === 'summarize' ? '📝 Summarizing' : '🔬 Analyzing'}...`);
    }
  } catch (err) {
    addLogItem('error', `Error: ${err.message}`);
  }
}

SIDE_BTN_SUMMARIZE.addEventListener('click', () => triggerAIAction('summarize'));
SIDE_BTN_ANALYZE.addEventListener('click', () => triggerAIAction('analyze'));

// ============================================================
// Bridge 连接
// ============================================================

SIDE_BTN_CONNECT.addEventListener('click', async () => {
  await chrome.storage.local.set({
    bridgeHost: SIDE_HOST.value,
    bridgePort: SIDE_PORT.value,
  });

  chrome.runtime.sendMessage({ type: 'bridge_connect' }, (result) => {
    updateBridgeUI(result?.connected || false);
  });
});

SIDE_BTN_DISCONNECT.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'bridge_disconnect' }, () => {
    updateBridgeUI(false);
  });
});

// ============================================================
// 日志
// ============================================================

function addLogItem(type, message) {
  const entry = document.createElement('div');
  entry.className = 'action-item';
  const time = new Date().toLocaleTimeString();
  entry.innerHTML = `<span>${message}</span><span class="action-time">${time}</span>`;

  const empty = SIDE_LOG.querySelector('.empty-state');
  if (empty) empty.remove();

  SIDE_LOG.insertBefore(entry, SIDE_LOG.firstChild);

  // 限制条目数
  while (SIDE_LOG.children.length > 50) {
    SIDE_LOG.removeChild(SIDE_LOG.lastChild);
  }
}

// ============================================================
// 启动
// ============================================================

init();
